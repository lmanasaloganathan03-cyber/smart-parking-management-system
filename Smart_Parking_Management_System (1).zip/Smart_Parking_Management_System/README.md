# Smart Parking Management System

Local academic mini-project using Python Flask, SQLite, HTML, CSS.

## Run on Windows
1. Extract the ZIP and open this folder in VS Code.
2. Open Terminal > New Terminal.
3. Run `py -m pip install -r requirements.txt`
4. Run `py app.py`
5. Open Chrome at `http://127.0.0.1:5000`

Keep the terminal open while using the app. Press Ctrl+C to stop it.

## Demo administrator
Email: `admin@parking.local`
Password: `Admin@123`

## Included
Customer registration/login, vehicle management, parking slot availability, booking/cancellation, admin slot CRUD, vehicle entry/exit, fee calculation and demo payment records. Database tables are created automatically in `parking.db`.

## Academic-demo limitations
This is a local demonstration. It does not connect to real sensors, cameras, barriers, maps, or payment gateways. Payments are recorded as demo entries only. Slot data is seeded as sample data. The app uses SQLite, not Oracle; confirm your lecturer's database requirement before submission. The sample secret key and debug server are for local development only.
