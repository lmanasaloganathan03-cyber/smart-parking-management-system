from pathlib import Path
from functools import wraps
from datetime import datetime
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash

app=Flask(__name__)
app.secret_key="local-classroom-demo-change-before-deployment"
DB=Path(__file__).with_name("parking.db")

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY AUTOINCREMENT,full_name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,phone TEXT,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'Customer' CHECK(role IN ('Customer','Admin')),created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS vehicles(vehicle_id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL REFERENCES users(user_id),plate_number TEXT UNIQUE NOT NULL,vehicle_type TEXT NOT NULL,model TEXT,color TEXT);
        CREATE TABLE IF NOT EXISTS parking_slots(slot_id INTEGER PRIMARY KEY AUTOINCREMENT,slot_code TEXT UNIQUE NOT NULL,floor_name TEXT NOT NULL,vehicle_type TEXT NOT NULL,hourly_rate REAL NOT NULL DEFAULT 30,status TEXT NOT NULL DEFAULT 'Available' CHECK(status IN ('Available','Reserved','Occupied','Maintenance')));
        CREATE TABLE IF NOT EXISTS reservations(reservation_id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL REFERENCES users(user_id),vehicle_id INTEGER NOT NULL REFERENCES vehicles(vehicle_id),slot_id INTEGER NOT NULL REFERENCES parking_slots(slot_id),start_time TEXT NOT NULL,end_time TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Booked' CHECK(status IN ('Booked','Cancelled','Completed')),created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS parking_records(record_id INTEGER PRIMARY KEY AUTOINCREMENT,reservation_id INTEGER UNIQUE NOT NULL REFERENCES reservations(reservation_id),entry_time TEXT,exit_time TEXT,duration_hours REAL DEFAULT 0,fee REAL DEFAULT 0,status TEXT NOT NULL DEFAULT 'Not Entered' CHECK(status IN ('Not Entered','Parked','Exited')));
        CREATE TABLE IF NOT EXISTS payments(payment_id INTEGER PRIMARY KEY AUTOINCREMENT,record_id INTEGER NOT NULL REFERENCES parking_records(record_id),amount REAL NOT NULL,payment_method TEXT NOT NULL,payment_status TEXT DEFAULT 'Recorded',paid_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
        if c.execute("SELECT COUNT(*) FROM parking_slots").fetchone()[0]==0:
            for n in range(1,21):
                c.execute("INSERT INTO parking_slots(slot_code,floor_name,vehicle_type,hourly_rate) VALUES(?,?,?,?)",
                (f"A{n:02}", "Ground Floor" if n<=10 else "First Floor","Two-wheeler" if n<=8 else ("Four-wheeler" if n<=18 else "Any"),15 if n<=8 else 30))
        if not c.execute("SELECT 1 FROM users WHERE email='admin@parking.local'").fetchone():
            c.execute("INSERT INTO users(full_name,email,phone,password_hash,role) VALUES(?,?,?,?,?)",
            ("Parking Administrator","admin@parking.local","0000000000",generate_password_hash("Admin@123"),"Admin"))

def logged(fn):
    @wraps(fn)
    def w(*a,**k):
        if not session.get("uid"): flash("Please log in first.","warning"); return redirect(url_for("login"))
        return fn(*a,**k)
    return w
def admin_only(fn):
    @wraps(fn)
    @logged
    def w(*a,**k):
        if session.get("role")!="Admin": abort(403)
        return fn(*a,**k)
    return w

@app.context_processor
def globals_(): return {"year":datetime.now().year}

@app.route("/")
def home():
    with db() as c:
        counts={x["status"]:x["n"] for x in c.execute("SELECT status,COUNT(*) n FROM parking_slots GROUP BY status")}
        slots=c.execute("SELECT * FROM parking_slots ORDER BY slot_code").fetchall()
    return render_template("home.html",counts=counts,slots=slots)

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        f=request.form; name=f.get("name","").strip(); email=f.get("email","").strip().lower(); pw=f.get("password","")
        if not name or not email or len(pw)<8 or pw!=f.get("confirm",""): flash("Enter all details and matching password (minimum 8 characters).","danger")
        else:
            try:
                with db() as c: c.execute("INSERT INTO users(full_name,email,phone,password_hash) VALUES(?,?,?,?)",(name,email,f.get("phone",""),generate_password_hash(pw)))
                flash("Account created. Please log in.","success"); return redirect(url_for("login"))
            except sqlite3.IntegrityError: flash("Email already registered.","danger")
    return render_template("register.html")

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        with db() as c: u=c.execute("SELECT * FROM users WHERE email=?",(request.form.get("email","").strip().lower(),)).fetchone()
        if u and check_password_hash(u["password_hash"],request.form.get("password","")):
            session.clear(); session.update(uid=u["user_id"],name=u["full_name"],role=u["role"])
            return redirect(url_for("admin" if u["role"]=="Admin" else "dashboard"))
        flash("Invalid email or password.","danger")
    return render_template("login.html")

@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("home"))

@app.route("/dashboard")
@logged
def dashboard():
    with db() as c:
        vehicles=c.execute("SELECT * FROM vehicles WHERE user_id=?",(session["uid"],)).fetchall()
        bookings=c.execute("""SELECT r.*,v.plate_number,s.slot_code,p.status park_status,p.fee FROM reservations r JOIN vehicles v ON v.vehicle_id=r.vehicle_id JOIN parking_slots s ON s.slot_id=r.slot_id LEFT JOIN parking_records p ON p.reservation_id=r.reservation_id WHERE r.user_id=? ORDER BY r.reservation_id DESC""",(session["uid"],)).fetchall()
    return render_template("dashboard.html",vehicles=vehicles,bookings=bookings)

@app.post("/vehicles/add")
@logged
def vehicle_add():
    f=request.form
    try:
        with db() as c: c.execute("INSERT INTO vehicles(user_id,plate_number,vehicle_type,model,color) VALUES(?,?,?,?,?)",(session["uid"],f["plate"].strip().upper(),f["type"],f.get("model",""),f.get("color","")))
        flash("Vehicle added.","success")
    except (sqlite3.IntegrityError,KeyError): flash("Invalid details or registration number already exists.","danger")
    return redirect(url_for("dashboard"))

@app.post("/vehicles/<int:vid>/delete")
@logged
def vehicle_delete(vid):
    with db() as c:
        active=c.execute("SELECT 1 FROM reservations WHERE vehicle_id=? AND user_id=? AND status='Booked'",(vid,session["uid"])).fetchone()
        if active: flash("Cancel active reservations before deleting this vehicle.","warning")
        else: c.execute("DELETE FROM vehicles WHERE vehicle_id=? AND user_id=?",(vid,session["uid"])); flash("Vehicle deleted.","success")
    return redirect(url_for("dashboard"))

@app.route("/slots")
def slots():
    with db() as c: rows=c.execute("SELECT * FROM parking_slots ORDER BY floor_name,slot_code").fetchall()
    return render_template("slots.html",slots=rows)

@app.route("/book/<int:sid>",methods=["GET","POST"])
@logged
def book(sid):
    with db() as c:
        slot=c.execute("SELECT * FROM parking_slots WHERE slot_id=?",(sid,)).fetchone()
        vehicles=c.execute("SELECT * FROM vehicles WHERE user_id=?",(session["uid"],)).fetchall()
        if not slot: abort(404)
        if request.method=="POST":
            try:
                v=c.execute("SELECT * FROM vehicles WHERE vehicle_id=? AND user_id=?",(int(request.form["vehicle_id"]),session["uid"])).fetchone()
                start=datetime.fromisoformat(request.form["start"]); end=datetime.fromisoformat(request.form["end"])
                if not v or end<=start: raise ValueError
                if slot["status"]!="Available": flash("Slot is no longer available.","warning")
                elif slot["vehicle_type"] not in ("Any",v["vehicle_type"]): flash("This slot does not match the selected vehicle type.","warning")
                else:
                    cur=c.execute("INSERT INTO reservations(user_id,vehicle_id,slot_id,start_time,end_time) VALUES(?,?,?,?,?)",(session["uid"],v["vehicle_id"],sid,request.form["start"],request.form["end"]))
                    c.execute("INSERT INTO parking_records(reservation_id) VALUES(?)",(cur.lastrowid,))
                    c.execute("UPDATE parking_slots SET status='Reserved' WHERE slot_id=?",(sid,))
                    flash("Parking slot reserved.","success"); return redirect(url_for("dashboard"))
            except (ValueError,KeyError): flash("Choose a vehicle and valid start/end times.","danger")
    return render_template("book.html",slot=slot,vehicles=vehicles)

@app.post("/reservations/<int:rid>/cancel")
@logged
def cancel(rid):
    with db() as c:
        r=c.execute("SELECT * FROM reservations WHERE reservation_id=? AND user_id=?",(rid,session["uid"])).fetchone()
        if not r: abort(404)
        if r["status"]=="Booked":
            c.execute("UPDATE reservations SET status='Cancelled' WHERE reservation_id=?",(rid,))
            c.execute("UPDATE parking_slots SET status='Available' WHERE slot_id=?",(r["slot_id"],))
            flash("Reservation cancelled.","success")
    return redirect(url_for("dashboard"))

@app.route("/admin")
@admin_only
def admin():
    with db() as c:
        slots=c.execute("SELECT * FROM parking_slots ORDER BY slot_code").fetchall()
        users=c.execute("SELECT user_id,full_name,email,phone,role FROM users ORDER BY user_id DESC").fetchall()
        bookings=c.execute("""SELECT r.*,u.full_name,v.plate_number,s.slot_code,p.record_id,p.status park_status,p.entry_time,p.exit_time,p.fee FROM reservations r JOIN users u ON u.user_id=r.user_id JOIN vehicles v ON v.vehicle_id=r.vehicle_id JOIN parking_slots s ON s.slot_id=r.slot_id LEFT JOIN parking_records p ON p.reservation_id=r.reservation_id ORDER BY r.reservation_id DESC""").fetchall()
        payments=c.execute("SELECT * FROM payments ORDER BY payment_id DESC").fetchall()
    stats={"users":len(users),"slots":len(slots),"available":sum(s["status"]=="Available" for s in slots),"occupied":sum(s["status"]=="Occupied" for s in slots)}
    return render_template("admin.html",slots=slots,users=users,bookings=bookings,payments=payments,stats=stats)

@app.post("/admin/slots/add")
@admin_only
def slot_add():
    f=request.form
    try:
        rate=float(f["rate"])
        if rate<0: raise ValueError
        with db() as c: c.execute("INSERT INTO parking_slots(slot_code,floor_name,vehicle_type,hourly_rate) VALUES(?,?,?,?)",(f["code"].strip().upper(),f["floor"].strip(),f["type"],rate))
        flash("Slot added.","success")
    except (ValueError,KeyError,sqlite3.IntegrityError): flash("Check details; slot code must be unique and rate valid.","danger")
    return redirect(url_for("admin")+"#slots")

@app.post("/admin/slots/<int:sid>/update")
@admin_only
def slot_update(sid):
    status=request.form.get("status")
    if status not in ("Available","Reserved","Occupied","Maintenance"): abort(400)
    with db() as c: c.execute("UPDATE parking_slots SET status=? WHERE slot_id=?",(status,sid))
    flash("Slot status updated.","success"); return redirect(url_for("admin")+"#slots")

@app.post("/admin/slots/<int:sid>/delete")
@admin_only
def slot_delete(sid):
    with db() as c:
        if c.execute("SELECT 1 FROM reservations WHERE slot_id=?",(sid,)).fetchone(): flash("Slot has booking history and cannot be deleted.","warning")
        else: c.execute("DELETE FROM parking_slots WHERE slot_id=?",(sid,)); flash("Slot deleted.","success")
    return redirect(url_for("admin")+"#slots")

@app.post("/admin/<int:rid>/entry")
@admin_only
def entry(rid):
    now=datetime.now().isoformat(timespec="minutes")
    with db() as c:
        r=c.execute("SELECT * FROM reservations WHERE reservation_id=? AND status='Booked'",(rid,)).fetchone()
        p=c.execute("SELECT * FROM parking_records WHERE reservation_id=?",(rid,)).fetchone()
        if not r or not p or p["status"]!="Not Entered": abort(400)
        c.execute("UPDATE parking_records SET entry_time=?,status='Parked' WHERE reservation_id=?",(now,rid))
        c.execute("UPDATE parking_slots SET status='Occupied' WHERE slot_id=?",(r["slot_id"],))
    flash("Vehicle entry recorded.","success"); return redirect(url_for("admin")+"#bookings")

@app.post("/admin/<int:rid>/exit")
@admin_only
def exit_(rid):
    now=datetime.now()
    with db() as c:
        p=c.execute("SELECT * FROM parking_records WHERE reservation_id=?",(rid,)).fetchone()
        r=c.execute("SELECT * FROM reservations WHERE reservation_id=?",(rid,)).fetchone()
        if not p or not r or p["status"]!="Parked": abort(400)
        start=datetime.fromisoformat(p["entry_time"])
        hours=max(1,int((now-start).total_seconds()/3600+0.9999))
        rate=c.execute("SELECT hourly_rate FROM parking_slots WHERE slot_id=?",(r["slot_id"],)).fetchone()[0]
        fee=hours*rate
        c.execute("UPDATE parking_records SET exit_time=?,duration_hours=?,fee=?,status='Exited' WHERE reservation_id=?",(now.isoformat(timespec="minutes"),hours,fee,rid))
        c.execute("UPDATE reservations SET status='Completed' WHERE reservation_id=?",(rid,))
        c.execute("UPDATE parking_slots SET status='Available' WHERE slot_id=?",(r["slot_id"],))
    flash(f"Vehicle exited. Demo fee: ₹{fee:.2f}. Record payment below.","success"); return redirect(url_for("admin")+"#payments")

@app.post("/admin/payments")
@admin_only
def payment():
    try:
        rec=int(request.form["record_id"]); method=request.form["method"]
        with db() as c:
            p=c.execute("SELECT fee,status FROM parking_records WHERE record_id=?",(rec,)).fetchone()
            if not p or p["status"]!="Exited": raise ValueError
            if c.execute("SELECT 1 FROM payments WHERE record_id=?",(rec,)).fetchone(): flash("Payment already recorded.","warning")
            else: c.execute("INSERT INTO payments(record_id,amount,payment_method) VALUES(?,?,?)",(rec,p["fee"],method)); flash("Demo payment recorded. No real payment was processed.","success")
    except (ValueError,KeyError): flash("Enter a valid exited parking record ID.","danger")
    return redirect(url_for("admin")+"#payments")

@app.errorhandler(403)
def forbidden(e): return render_template("message.html",title="Access denied",message="Administrator access is required."),403
@app.errorhandler(404)
def missing(e): return render_template("message.html",title="Not found",message="The requested page or record was not found."),404

if __name__=="__main__":
    init_db()
    app.run(debug=True)
